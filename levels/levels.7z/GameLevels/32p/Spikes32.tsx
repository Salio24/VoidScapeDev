<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Spikes32" tilewidth="32" tileheight="32" tilecount="172" columns="43">
 <image source="../../tiles/Spikes32.png" width="1376" height="128"/>
</tileset>
